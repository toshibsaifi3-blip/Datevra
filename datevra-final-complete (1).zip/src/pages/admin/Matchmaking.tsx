import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import type { Match, UserProfile } from "../../lib/types";
import { useAsync, useBackend } from "../../lib/data";
import { Avatar, Badge, EmptyState, SectionHead, Skeleton, Stat, inputCls } from "../../components/ui";
import { fmtDate } from "./_util";

export default function Matchmaking() {
  const db = useBackend();
  const [city, setCity] = useState("all");

  const { data: users, loading: uLoading, error: uError } = useAsync(
    (b) => b.allUsers(),
    [db],
    [] as UserProfile[],
  );
  const {
    data: matchLists,
    loading: mLoading,
    error: mError,
    refresh,
  } = useAsync(
    (b) => Promise.all(users.map((u) => b.matchesFor(u.id))),
    [db, users],
    [] as Match[][],
  );

  useEffect(() => db.subscribe("matches", refresh), [db, refresh]);

  const userMap = useMemo(() => new Map(users.map((u) => [u.id, u])), [users]);

  const matches = useMemo(() => {
    const seen = new Map<string, Match>();
    for (const list of matchLists) {
      for (const m of list) seen.set(m.id, m);
    }
    return [...seen.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [matchLists]);

  const cities = useMemo(() => {
    const s = new Set<string>();
    for (const m of matches) {
      const a = userMap.get(m.userA);
      const b = userMap.get(m.userB);
      if (a) s.add(a.city);
      if (b) s.add(b.city);
    }
    return [...s].sort();
  }, [matches, userMap]);

  const filtered = matches.filter((m) => {
    if (city === "all") return true;
    return userMap.get(m.userA)?.city === city || userMap.get(m.userB)?.city === city;
  });

  const avgCompat =
    matches.length === 0
      ? 0
      : Math.round(matches.reduce((s, m) => s + m.compatibility, 0) / matches.length);

  const loading = uLoading || mLoading;
  const error = uError ?? mError;

  return (
    <div className="px-5 pb-24 pt-10 md:pt-14">
      <div className="max-w-6xl mx-auto">
        <SectionHead
          kicker="Match engine"
          title="Matchmaking"
          sub="Read-only analytics of every mutual match. Paid visibility never overrides a user's preferences or consent."
          align="left"
        />
        {error && <p className="mt-6 text-sm text-rosegold">Couldn&apos;t load matches: {error}</p>}

        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-28" />
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
              <Stat label="Total matches" value={matches.length} sub="mutual interest pairs" />
              <Stat label="Avg compatibility" value={`${avgCompat}%`} sub="preference-based score" />
              <Stat label="Cities active" value={cities.length} sub="with at least one match" />
              <Stat
                label="In view"
                value={filtered.length}
                sub={city === "all" ? "all cities" : city}
              />
            </div>

            <div className="mt-8 glass rounded-2xl p-4 flex items-center gap-3">
              <select value={city} onChange={(e) => setCity(e.target.value)} className={`${inputCls} max-w-xs`}>
                <option value="all">All cities</option>
                {cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <span className="text-sm text-mist">{filtered.length} matches</span>
            </div>

            {filtered.length === 0 ? (
              <div className="mt-6">
                <EmptyState title="No matches yet" body="Mutual likes will create matches that appear here." />
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-5 mt-6">
                {filtered.map((m, idx) => {
                  const a = userMap.get(m.userA);
                  const b = userMap.get(m.userB);
                  return (
                    <motion.div
                      key={m.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: Math.min(idx * 0.05, 0.3) }}
                      className="glass rounded-3xl p-6"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar name={a?.firstName ?? "?"} size={52} ring />
                          <Avatar name={b?.firstName ?? "?"} size={52} ring />
                          <div>
                            <p className="text-ivory font-medium">
                              {a?.firstName} <span className="text-rosegold">✦</span> {b?.firstName}
                            </p>
                            <p className="text-xs text-mist">
                              {a?.city} · {b?.city} · {fmtDate(m.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="font-display text-3xl text-gradient-gold">{m.compatibility}%</p>
                          <p className="text-[0.65rem] uppercase tracking-[0.2em] text-mist">compatible</p>
                        </div>
                      </div>
                      <div className="h-2 rounded-full bg-white/5 overflow-hidden mt-4">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${m.compatibility}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8 }}
                          className="h-full rounded-full bg-gradient-to-r from-champagne to-rosegold"
                        />
                      </div>
                      <div className="flex flex-wrap gap-1.5 mt-4">
                        {m.factors.map((f) => (
                          <Badge key={f} tone="muted">
                            {f}
                          </Badge>
                        ))}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
